Visit http://merenlab.org/momics/exercises/read-recruitment/ for details :)
